package com.vedant.user_feedback_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserFeedbackServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
